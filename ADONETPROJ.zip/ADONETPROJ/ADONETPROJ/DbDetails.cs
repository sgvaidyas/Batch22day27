﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJ.Model;

namespace ADONETPROJ
{
    public partial class DbDetails : Form
    {
        studentLogic ob = new studentLogic();
        public DbDetails()
        {
            InitializeComponent();
        }

        private void DbDetails_Load(object sender, EventArgs e)
        {
           
            cbtables.DataSource = ob.getabledata().Tables[0];
            cbtables.DisplayMember = "name";
        }
        //display
        private void button1_Click(object sender, EventArgs e)
        {
            int i = cbtables.SelectedIndex;
            //MessageBox.Show(i.ToString());
            i++;
            dataGridView1.DataSource = ob.getabledata().Tables[i];
        }
    }
}
