﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJ.Model;
namespace ADONETPROJ
{
    public partial class UpdateData : Form
    {
        studentLogic ob = new studentLogic();
        public UpdateData()
        {
            InitializeComponent();
        }


        private void UpdateData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            panel1.Visible = false;
            btnUpdate.Visible = false;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                panel1.Visible = true;
                txtName.Text    = res.Tables[0].Rows[0]["studentname"].ToString();
                txtEmail.Text   = res.Tables[0].Rows[0]["Email"].ToString();
                txtPhone.Text   = res.Tables[0].Rows[0]["Phone"].ToString();
                txtFees.Text    = res.Tables[0].Rows[0]["Fees"].ToString();
                txtPercent.Text = res.Tables[0].Rows[0]["Percent"].ToString();
                btnUpdate.Visible = true;

                /*
                Student stu = new Student();

                stu.Id = id;
                stu.Name = res.Tables[0].Rows[0]["studentname"].ToString();
                stu.Email = res.Tables[0].Rows[0]["Email"].ToString();
                stu.Phone = res.Tables[0].Rows[0]["Phone"].ToString();
                stu.Fees = float.Parse(res.Tables[0].Rows[0]["Fees"].ToString());
                stu.Percent = float.Parse(res.Tables[0].Rows[0]["Percent"].ToString());

                MessageBox.Show(stu.ToString());
                */
            }
            else
            {
                MessageBox.Show("Record wrt the id does not exist");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Student s = new Student();

            s.Id = Convert.ToInt32(txtId.Value);
            s.Name = txtName.Text;
            s.Email = txtEmail.Text;
            s.Phone = txtPhone.Text;
            s.Fees = float.Parse(txtFees.Text.ToString());
            s.Percent = float.Parse(txtPercent.Text.ToString());

            string msg = ob.Updatedata(s);
            MessageBox.Show(msg);
            dataGridView1.DataSource = ob.getStudentDetails();
            dataGridView1.Visible = true;
        }
    }
}
