﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ADONETPROJ.Model;
namespace ADONETPROJ
{
    public partial class Deletedata : Form
    {
        studentLogic ob = new studentLogic();

        public Deletedata()
        {
            InitializeComponent();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Value.ToString());
            DataSet res = ob.GetSearchData(id);
            if (Convert.ToInt32(res.Tables[0].Rows.Count.ToString()) > 0)
            {
                string msg = ob.DeleteData(id);
                MessageBox.Show(msg);
            }
            else
            {
                MessageBox.Show("ID DOES NOT EXIST");
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 ob1 = new Form1();
            ob1.Show();
            this.Hide();
        }
    }
}
